// ===============================
// ADMIN ACCESS CHECK
// ===============================

const loggedInRole =
    localStorage.getItem("loggedInRole");


if (loggedInRole !== "admin") {

    alert("Please login as an administrator.");

    window.location.href =
        "index.html";

}


// ===============================
// DEFAULT ADMIN
// ===============================

const defaultAdmin = {

    firstName: "Admin",

    lastName: "User",

    email: "admin@company.com"

};


const admin =
    JSON.parse(
        localStorage.getItem("adminProfile")
    ) || defaultAdmin;


// ===============================
// DISPLAY ADMIN NAME
// ===============================

const adminFullName =
    `${admin.firstName || ""} ${admin.lastName || ""}`
        .trim();


const headerAdminName =
    document.getElementById(
        "headerAdminName"
    );


if (headerAdminName) {

    headerAdminName.textContent =
        adminFullName || "Admin";

}


// ===============================
// LOAD DATA
// ===============================

let employees = [];

let departments = [];


// ===============================
// LOAD EMPLOYEES
// ===============================

async function loadEmployees() {

    try {

        const response =
            await fetch(
                "data/employees.json"
            );


        if (!response.ok) {

            throw new Error(
                "Unable to load employees."
            );

        }


        const employeesFromJSON =
            await response.json();


        const savedEmployees =
            JSON.parse(
                localStorage.getItem(
                    "employees"
                )
            ) || [];


        // ===============================
        // MERGE EMPLOYEES
        // ===============================

        const employeeMap =
            new Map();


        employeesFromJSON.forEach(employee => {

            employeeMap.set(
                employee.employeeId,
                employee
            );

        });


        savedEmployees.forEach(employee => {

            employeeMap.set(
                employee.employeeId,
                {
                    ...employeeMap.get(
                        employee.employeeId
                    ),
                    ...employee
                }
            );

        });


        employees =
            Array.from(
                employeeMap.values()
            );


        displayEmployees();

        updateDashboardCounts();

    } catch (error) {

        console.error(error);

    }

}


// ===============================
// LOAD DEPARTMENTS
// ===============================

async function loadDepartments() {

    try {

        const response =
            await fetch(
                "data/departments.json"
            );


        if (!response.ok) {

            throw new Error(
                "Unable to load departments."
            );

        }


        const departmentsFromJSON =
            await response.json();


        const savedDepartments =
            JSON.parse(
                localStorage.getItem(
                    "departments"
                )
            ) || [];


        // ===============================
        // MERGE DEPARTMENTS
        // ===============================

        const departmentMap =
            new Map();


        departmentsFromJSON.forEach(department => {

            departmentMap.set(
                department.departmentId,
                department
            );

        });


        savedDepartments.forEach(department => {

            departmentMap.set(
                department.departmentId,
                {
                    ...departmentMap.get(
                        department.departmentId
                    ),
                    ...department
                }
            );

        });


        departments =
            Array.from(
                departmentMap.values()
            );


        displayDepartments();

        updateDashboardCounts();

    } catch (error) {

        console.error(error);

    }

}


// ===============================
// UPDATE DASHBOARD COUNTS
// ===============================

function updateDashboardCounts() {

    const totalEmployees =
        document.getElementById(
            "totalEmployees"
        );


    const totalDepartments =
        document.getElementById(
            "totalDepartments"
        );


    const activeEmployees =
        document.getElementById(
            "activeEmployees"
        );


    const inactiveEmployees =
        document.getElementById(
            "inactiveEmployees"
        );


    if (totalEmployees) {

        totalEmployees.textContent =
            employees.length;

    }


    if (totalDepartments) {

        totalDepartments.textContent =
            departments.length;

    }


    if (activeEmployees) {

        activeEmployees.textContent =
            employees.filter(
                employee =>
                    employee.status === "Active"
            ).length;

    }


    if (inactiveEmployees) {

        inactiveEmployees.textContent =
            employees.filter(
                employee =>
                    employee.status === "Inactive"
            ).length;

    }

}


// ===============================
// DISPLAY EMPLOYEES
// ===============================

function displayEmployees() {

    const tableBody =
        document.getElementById(
            "employeeTableBody"
        );


    if (!tableBody) {

        return;

    }


    tableBody.innerHTML = "";


    employees.forEach(employee => {

        const row =
            document.createElement("tr");


        const fullName =
            `${employee.firstName || ""} ${employee.lastName || ""}`
                .trim();


        row.innerHTML = `

            <td>${employee.employeeId || "-"}</td>

            <td>${fullName || "-"}</td>

            <td>${employee.email || "-"}</td>

            <td>${employee.department || "-"}</td>

            <td>${employee.designation || "-"}</td>

            <td>${employee.joiningDate || "-"}</td>

            <td>${employee.status || "-"}</td>

        `;


        tableBody.appendChild(row);

    });

}


// ===============================
// DISPLAY DEPARTMENTS
// ===============================

function displayDepartments() {

    const departmentContainer =
        document.getElementById(
            "departmentList"
        );


    if (!departmentContainer) {

        return;

    }


    departmentContainer.innerHTML = "";


    departments.forEach(department => {

        const item =
            document.createElement("div");


        item.className =
            "department-item";


        item.innerHTML = `

            <strong>
                ${department.departmentName || "-"}
            </strong>

            <span>
                Manager:
                ${department.manager || "-"}
            </span>

        `;


        departmentContainer.appendChild(item);

    });

}


// ===============================
// EMPLOYEE SEARCH
// ===============================

const employeeSearch =
    document.getElementById(
        "employeeSearch"
    );


if (employeeSearch) {

    employeeSearch.addEventListener(
        "input",
        function () {

            const searchTerm =
                this.value
                    .trim()
                    .toLowerCase();


            const results =
                employees.filter(
                    employee => {

                        const fullName =
                            `${employee.firstName || ""} ${employee.lastName || ""}`
                                .toLowerCase();


                        return (

                            employee.employeeId
                                ?.toLowerCase()
                                .includes(searchTerm)

                            ||

                            employee.email
                                ?.toLowerCase()
                                .includes(searchTerm)

                            ||

                            fullName.includes(
                                searchTerm
                            )

                        );

                    }
                );


            displaySearchResults(results);

        }
    );

}


// ===============================
// DISPLAY SEARCH RESULTS
// ===============================

function displaySearchResults(results) {

    const resultsContainer =
        document.getElementById(
            "searchResults"
        );


    if (!resultsContainer) {

        return;

    }


    resultsContainer.innerHTML = "";


    results.forEach(employee => {

        const result =
            document.createElement("div");


        const fullName =
            `${employee.firstName || ""} ${employee.lastName || ""}`
                .trim();


        result.className =
            "search-result";


        result.textContent =
            `${employee.employeeId} - ${fullName || employee.email}`;


        result.addEventListener(
            "click",
            function () {

                displayEmployeeDetails(
                    employee
                );

            }
        );


        resultsContainer.appendChild(
            result
        );

    });

}


// ===============================
// EMPLOYEE DETAILS
// ===============================

function displayEmployeeDetails(employee) {

    const details =
        document.getElementById(
            "employeeDetails"
        );


    if (!details) {

        return;

    }


    const fullName =
        `${employee.firstName || ""} ${employee.lastName || ""}`
            .trim();


    details.innerHTML = `

        <h3>
            ${fullName || "-"}
        </h3>

        <p>
            <strong>Employee ID:</strong>
            ${employee.employeeId || "-"}
        </p>

        <p>
            <strong>Email:</strong>
            ${employee.email || "-"}
        </p>

        <p>
            <strong>Department:</strong>
            ${employee.department || "-"}
        </p>

        <p>
            <strong>Manager:</strong>
            ${employee.manager || "-"}
        </p>

        <p>
            <strong>Designation:</strong>
            ${employee.designation || "-"}
        </p>

        <p>
            <strong>Joining Date:</strong>
            ${employee.joiningDate || "-"}
        </p>

        <p>
            <strong>Status:</strong>
            ${employee.status || "-"}
        </p>

    `;

}


// ===============================
// LOGOUT
// ===============================

const adminLogout =
    document.getElementById(
        "adminLogout"
    );


if (adminLogout) {

    adminLogout.addEventListener(
        "click",
        function (event) {

            event.preventDefault();


            const confirmLogout =
                confirm(
                    "Are you sure you want to logout?"
                );


            if (confirmLogout) {

                localStorage.removeItem(
                    "loggedInRole"
                );

                window.location.href =
                    "index.html";

            }

        }
    );

}


// ===============================
// INITIAL LOAD
// ===============================

loadEmployees();

loadDepartments();