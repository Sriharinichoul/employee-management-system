// ===============================
// LOAD DEPARTMENTS
// ===============================

async function loadDepartments() {

    try {

        const response =
            await fetch("data/departments.json");

        if (!response.ok) {
            throw new Error("Unable to load departments.");
        }

        const departmentsFromJSON =
            await response.json();

        const savedDepartments =
            JSON.parse(
                localStorage.getItem("departments")
            ) || [];


        // Merge JSON departments with
        // departments created in the application

        const departmentMap = new Map();

        departmentsFromJSON.forEach(department => {

            departmentMap.set(
                department.departmentId,
                department
            );

        });

        savedDepartments.forEach(department => {

            departmentMap.set(
                department.departmentId,
                {
                    ...departmentMap.get(
                        department.departmentId
                    ),
                    ...department
                }
            );

        });


        const departments =
            Array.from(
                departmentMap.values()
            );


        // ===============================
        // DEPARTMENT DROPDOWN
        // ===============================

        const departmentSelect =
            document.getElementById("department");


        departmentSelect.innerHTML =
            '<option value="">Select Department</option>';


        departments.forEach(department => {

            const option =
                document.createElement("option");

            option.value =
                department.departmentName;

            option.textContent =
                department.departmentName;

            departmentSelect.appendChild(option);

        });


        // ===============================
        // MANAGER DROPDOWN
        // ===============================

        const managerSelect =
            document.getElementById("manager");


        managerSelect.innerHTML =
            '<option value="">Select Manager</option>';


        // Get employees because managers
        // can be existing employees

        const employeeResponse =
            await fetch("data/employees.json");

        const employeesFromJSON =
            await employeeResponse.json();


        const savedEmployees =
            JSON.parse(
                localStorage.getItem("employees")
            ) || [];


        const employeeMap = new Map();


        employeesFromJSON.forEach(employee => {

            employeeMap.set(
                employee.employeeId,
                employee
            );

        });


        savedEmployees.forEach(employee => {

            employeeMap.set(
                employee.employeeId,
                {
                    ...employeeMap.get(
                        employee.employeeId
                    ),
                    ...employee
                }
            );

        });


        const employees =
            Array.from(
                employeeMap.values()
            );


        employees.forEach(employee => {

            const fullName =
                `${employee.firstName || ""} ${employee.lastName || ""}`
                    .trim();


            if (!fullName) {
                return;
            }


            const option =
                document.createElement("option");


            option.value = fullName;

            option.textContent = fullName;


            managerSelect.appendChild(option);

        });


    } catch (error) {

        console.error(error);

        alert(
            "Unable to load department information."
        );

    }

}


// ===============================
// LOAD FORM DATA
// ===============================

loadDepartments();


// ===============================
// EMPLOYEE FORM
// ===============================

const employeeForm =
    document.getElementById("employeeForm");


employeeForm.addEventListener(
    "submit",
    function (event) {

        event.preventDefault();


        // ===============================
        // GET FORM VALUES
        // ===============================

        const employeeId =
            document.getElementById(
                "employeeId"
            ).value.trim();


        const email =
            document.getElementById(
                "email"
            ).value.trim();


        const department =
            document.getElementById(
                "department"
            ).value;


        const manager =
            document.getElementById(
                "manager"
            ).value;


        const designation =
            document.getElementById(
                "designation"
            ).value.trim();


        const joiningDate =
            document.getElementById(
                "joiningDate"
            ).value;


        const status =
            document.getElementById(
                "status"
            ).value;


        // ===============================
        // VALIDATION
        // ===============================

        if (
            employeeId === "" ||
            email === "" ||
            department === "" ||
            manager === "" ||
            designation === "" ||
            joiningDate === ""
        ) {

            alert(
                "Please fill in all the required fields."
            );

            return;

        }


        // ===============================
        // GET SAVED EMPLOYEES
        // ===============================

        const savedEmployees =
            JSON.parse(
                localStorage.getItem("employees")
            ) || [];


        // ===============================
        // CHECK DUPLICATE ID
        // ===============================

        const employeeIdExists =
            savedEmployees.some(
                employee =>
                    employee.employeeId &&
                    employee.employeeId.toLowerCase()
                    === employeeId.toLowerCase()
            );


        if (employeeIdExists) {

            alert(
                "This Employee ID already exists."
            );

            return;

        }


        // ===============================
        // CHECK DUPLICATE EMAIL
        // ===============================

        const emailExists =
            savedEmployees.some(
                employee =>
                    employee.email &&
                    employee.email.toLowerCase()
                    === email.toLowerCase()
            );


        if (emailExists) {

            alert(
                "This email address is already registered."
            );

            return;

        }


        // ===============================
        // CREATE EMPLOYEE
        // ===============================

        const newEmployee = {

            employeeId: employeeId,

            email: email,

            department: department,

            manager: manager,

            designation: designation,

            joiningDate: joiningDate,

            status: status,

            role: "Employee",

            firstLogin: true

        };


        savedEmployees.push(
            newEmployee
        );


        localStorage.setItem(
            "employees",
            JSON.stringify(
                savedEmployees
            )
        );


        // ===============================
        // CREATE DEFAULT PASSWORD
        // ===============================

        const employeePasswords =
            JSON.parse(
                localStorage.getItem(
                    "employeePasswords"
                )
            ) || {};


        employeePasswords[employeeId] =
            "employee123";


        localStorage.setItem(
            "employeePasswords",
            JSON.stringify(
                employeePasswords
            )
        );


        // ===============================
        // SUCCESS
        // ===============================

        alert(
            "Employee added successfully!\n\n" +
            "Default password: employee123"
        );


        window.location.href =
            "employees.html";

    }
);