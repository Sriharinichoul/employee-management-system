let employees = [];


// Load employees from JSON
fetch("data/employees.json")
    .then(response => response.json())
    .then(data => {

        // Get employees added or updated through the application
        const savedEmployees =
            JSON.parse(localStorage.getItem("employees")) || [];


        // Start with employees from JSON
        employees = [...data];


        // Add/update employees from localStorage
        savedEmployees.forEach(savedEmployee => {

            const existingIndex =
                employees.findIndex(
                    employee =>
                        employee.employeeId.toLowerCase() ===
                        savedEmployee.employeeId.toLowerCase()
                );


            if (existingIndex !== -1) {

                // Replace the JSON employee
                // with the updated version
                employees[existingIndex] =
                    savedEmployee;

            } else {

                // Add newly created employee
                employees.push(savedEmployee);

            }

        });


        // Display employees
        displayEmployees(employees);

    })
    .catch(error => {

        console.error(
            "Error loading employee data:",
            error
        );

    });



// Display employees
function displayEmployees(employeeList) {

    const tableBody =
        document.getElementById("employeeTableBody");


    tableBody.innerHTML = "";


    employeeList.forEach(employee => {

        const row =
            document.createElement("tr");


        // Display name only if available
        let employeeName = "-";


        if (
            employee.firstName &&
            employee.lastName
        ) {

            employeeName =
                employee.firstName +
                " " +
                employee.lastName;

        }


        row.innerHTML = `

            <td>
                ${employee.employeeId}
            </td>

            <td>
                ${employeeName}
            </td>

            <td>
                ${employee.email}
            </td>

            <td>
                ${employee.department}
            </td>

            <td>
                ${employee.designation}
            </td>

            <td>
                ${employee.joiningDate}
            </td>

            <td>
                ${employee.status}
            </td>

            <td>

                <a
                    href="edit-employee.html?id=${employee.employeeId}"
                >
                    Edit
                </a>

            </td>

        `;


        tableBody.appendChild(row);

    });

}



// Search employees
const employeeSearch =
    document.getElementById("employeeSearch");


employeeSearch.addEventListener(
    "input",
    function() {

        const searchText =
            employeeSearch.value.toLowerCase();


        const filteredEmployees =
            employees.filter(function(employee) {

                const employeeId =
                    employee.employeeId.toLowerCase();


                const email =
                    employee.email.toLowerCase();


                let fullName = "";


                if (
                    employee.firstName &&
                    employee.lastName
                ) {

                    fullName =
                        employee.firstName +
                        " " +
                        employee.lastName;

                }


                return (
                    employeeId.includes(searchText) ||
                    email.includes(searchText) ||
                    fullName
                        .toLowerCase()
                        .includes(searchText)
                );

            });


        displayEmployees(filteredEmployees);

    }
);