const profileForm =
    document.getElementById(
        "completeProfileForm"
    );



const currentEmployeeId =
    localStorage.getItem(
        "currentEmployeeId"
    );


if (!currentEmployeeId) {

    window.location.href =
        "employee-login.html";

}



let employees = [];



// ==================================================
// LOAD EMPLOYEE
// ==================================================

fetch("data/employees.json")
    .then(response => response.json())
    .then(data => {

        const savedEmployees =
            JSON.parse(
                localStorage.getItem(
                    "employees"
                )
            ) || [];


        employees = [...data];


        savedEmployees.forEach(
            savedEmployee => {

                const existingIndex =
                    employees.findIndex(
                        employee =>
                            employee.employeeId
                                .toLowerCase() ===
                            savedEmployee.employeeId
                                .toLowerCase()
                    );


                if (existingIndex !== -1) {

                    employees[
                        existingIndex
                    ] =
                        {
                            ...employees[
                                existingIndex
                            ],
                            ...savedEmployee
                        };

                } else {

                    employees.push(
                        savedEmployee
                    );

                }

            }
        );


        const employee =
            employees.find(
                employee =>
                    employee.employeeId
                        .toLowerCase() ===
                    currentEmployeeId
                        .toLowerCase()
            );


        if (!employee) {

            alert(
                "Employee account not found."
            );

            localStorage.removeItem(
                "currentEmployeeId"
            );

            window.location.href =
                "employee-login.html";

            return;

        }


        // Pre-fill existing information

        document.getElementById(
            "firstName"
        ).value =
            employee.firstName || "";


        document.getElementById(
            "lastName"
        ).value =
            employee.lastName || "";


        document.getElementById(
            "dateOfBirth"
        ).value =
            employee.dateOfBirth || "";


        document.getElementById(
            "mobileNumber"
        ).value =
            employee.mobileNumber || "";


        document.getElementById(
            "bloodGroup"
        ).value =
            employee.bloodGroup || "";


        document.getElementById(
            "address"
        ).value =
            employee.address || "";


        document.getElementById(
            "city"
        ).value =
            employee.city || "";


        document.getElementById(
            "state"
        ).value =
            employee.state || "";


        document.getElementById(
            "postalCode"
        ).value =
            employee.postalCode || "";


        document.getElementById(
            "emergencyContactName"
        ).value =
            employee.emergencyContactName || "";


        document.getElementById(
            "emergencyContactNumber"
        ).value =
            employee.emergencyContactNumber || "";


        document.getElementById(
            "emergencyContactRelationship"
        ).value =
            employee.emergencyContactRelationship || "";

    })
    .catch(error => {

        console.error(
            "Error loading employee:",
            error
        );

    });



// ==================================================
// SAVE PROFILE
// ==================================================

profileForm.addEventListener(
    "submit",
    function(event) {

        event.preventDefault();


        const savedEmployees =
            JSON.parse(
                localStorage.getItem(
                    "employees"
                )
            ) || [];


        const employeeIndex =
            savedEmployees.findIndex(
                employee =>
                    employee.employeeId
                        .toLowerCase() ===
                    currentEmployeeId
                        .toLowerCase()
            );


        if (employeeIndex === -1) {

            alert(
                "Employee account could not be found."
            );

            return;

        }


        const employee =
            savedEmployees[
                employeeIndex
            ];


        // Update personal information

        employee.firstName =
            document.getElementById(
                "firstName"
            ).value.trim();


        employee.lastName =
            document.getElementById(
                "lastName"
            ).value.trim();


        employee.dateOfBirth =
            document.getElementById(
                "dateOfBirth"
            ).value;


        employee.mobileNumber =
            document.getElementById(
                "mobileNumber"
            ).value.trim();


        employee.bloodGroup =
            document.getElementById(
                "bloodGroup"
            ).value;


        employee.address =
            document.getElementById(
                "address"
            ).value.trim();


        employee.city =
            document.getElementById(
                "city"
            ).value.trim();


        employee.state =
            document.getElementById(
                "state"
            ).value.trim();


        employee.postalCode =
            document.getElementById(
                "postalCode"
            ).value.trim();


        employee.emergencyContactName =
            document.getElementById(
                "emergencyContactName"
            ).value.trim();


        employee.emergencyContactNumber =
            document.getElementById(
                "emergencyContactNumber"
            ).value.trim();


        employee.emergencyContactRelationship =
            document.getElementById(
                "emergencyContactRelationship"
            ).value.trim();


        // First login completed

        employee.firstLogin =
            false;


        savedEmployees[
            employeeIndex
        ] =
            employee;


        localStorage.setItem(
            "employees",
            JSON.stringify(
                savedEmployees
            )
        );


        alert(
            "Profile completed successfully!"
        );


        window.location.href =
            "employee-dashboard.html";

    }
);



// ==================================================
// LOGOUT
// ==================================================

document
    .getElementById("profileLogout")
    .addEventListener(
        "click",
        function(event) {

            event.preventDefault();


            localStorage.removeItem(
                "currentEmployeeId"
            );


            window.location.href =
                "employee-login.html";

        }
    );