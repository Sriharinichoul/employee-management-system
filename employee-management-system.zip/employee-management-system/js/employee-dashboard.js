let employees = [];

let departments = [];

let currentEmployee = null;



// ==================================================
// LOAD EMPLOYEES
// ==================================================

function loadEmployees() {

    fetch("data/employees.json")

        .then(response => response.json())

        .then(data => {

            const savedEmployees =
                JSON.parse(
                    localStorage.getItem("employees")
                ) || [];


            // Start with JSON employees

            employees = [...data];


            // Add employees from localStorage
            // and replace existing records if needed

            savedEmployees.forEach(
                savedEmployee => {

                    const existingIndex =
                        employees.findIndex(
                            employee =>
                                employee.employeeId
                                    .toLowerCase() ===
                                savedEmployee.employeeId
                                    .toLowerCase()
                        );


                    if (existingIndex !== -1) {

                        employees[existingIndex] = {
                            ...employees[existingIndex],
                            ...savedEmployee
                        };

                    } else {

                        employees.push(
                            savedEmployee
                        );

                    }

                }
            );


            /*
                TEMPORARY TESTING

                Until we connect your existing login page,
                we use EMP001 as the employee currently
                viewing the dashboard.

                Later, index.html will store the actual
                logged-in employee ID in localStorage.
            */

            const currentEmployeeId =
                localStorage.getItem(
                    "currentEmployeeId"
                ) || "EMP001";


            currentEmployee =
                employees.find(
                    employee =>
                        employee.employeeId
                            .toLowerCase() ===
                        currentEmployeeId
                            .toLowerCase()
                );


            if (!currentEmployee) {

                alert(
                    "Employee information could not be found."
                );

                return;

            }


            displayCurrentEmployee();


            loadDepartments();

        })

        .catch(error => {

            console.error(
                "Error loading employees:",
                error
            );

        });

}



// ==================================================
// DISPLAY CURRENT EMPLOYEE
// ==================================================

function displayCurrentEmployee() {

    const firstName =
        currentEmployee.firstName || "";


    const lastName =
        currentEmployee.lastName || "";


    const fullName =
        `${firstName} ${lastName}`.trim();


    const displayName =
        fullName ||
        currentEmployee.employeeId;


    document.getElementById(
        "headerEmployeeName"
    ).textContent =
        displayName;


    document.getElementById(
        "welcomeMessage"
    ).textContent =
        `Welcome, ${displayName}`;


    document.getElementById(
        "employeeId"
    ).textContent =
        currentEmployee.employeeId;


    document.getElementById(
        "employeeEmail"
    ).textContent =
        currentEmployee.email || "-";


    document.getElementById(
        "employeeDepartment"
    ).textContent =
        currentEmployee.department || "-";


    document.getElementById(
        "employeeManager"
    ).textContent =
        currentEmployee.manager || "-";


    document.getElementById(
        "employeeDesignation"
    ).textContent =
        currentEmployee.designation || "-";


    document.getElementById(
        "employeeJoiningDate"
    ).textContent =
        currentEmployee.joiningDate || "-";


    document.getElementById(
        "employeeStatus"
    ).textContent =
        currentEmployee.status || "-";

}



// ==================================================
// LOAD DEPARTMENTS
// ==================================================

function loadDepartments() {

    fetch("data/departments.json")

        .then(response => response.json())

        .then(data => {

            const savedDepartments =
                JSON.parse(
                    localStorage.getItem("departments")
                ) || [];


            departments = [...data];


            savedDepartments.forEach(
                savedDepartment => {

                    const existingIndex =
                        departments.findIndex(
                            department =>
                                department.departmentId
                                    .toLowerCase() ===
                                savedDepartment.departmentId
                                    .toLowerCase()
                        );


                    if (existingIndex !== -1) {

                        departments[
                            existingIndex
                        ] =
                            {
                                ...departments[
                                    existingIndex
                                ],
                                ...savedDepartment
                            };

                    } else {

                        departments.push(
                            savedDepartment
                        );

                    }

                }
            );

        })

        .catch(error => {

            console.error(
                "Error loading departments:",
                error
            );

        });

}



// ==================================================
// SEARCH EMPLOYEES
// ==================================================

document
    .getElementById("employeeSearch")
    .addEventListener(
        "input",
        function() {

            const searchText =
                this.value
                    .toLowerCase()
                    .trim();


            const resultsContainer =
                document.getElementById(
                    "employeeSearchResults"
                );


            const selectedEmployee =
                document.getElementById(
                    "selectedEmployee"
                );


            resultsContainer.innerHTML = "";

            selectedEmployee.innerHTML = "";


            if (searchText === "") {

                return;

            }


            const results =
                employees.filter(
                    employee => {

                        const employeeId =
                            (
                                employee.employeeId ||
                                ""
                            ).toLowerCase();


                        const email =
                            (
                                employee.email ||
                                ""
                            ).toLowerCase();


                        const fullName =
                            `${employee.firstName || ""} ${employee.lastName || ""}`
                                .toLowerCase();


                        return (
                            employeeId.includes(
                                searchText
                            ) ||
                            email.includes(
                                searchText
                            ) ||
                            fullName.includes(
                                searchText
                            )
                        );

                    }
                );


            results.forEach(
                employee => {

                    const result =
                        document.createElement(
                            "div"
                        );


                    result.className =
                        "employee-search-result";


                    const fullName =
                        `${employee.firstName || ""} ${employee.lastName || ""}`
                            .trim();


                    result.innerHTML = `

                        <strong>
                            ${fullName || employee.employeeId}
                        </strong>

                        <span>
                            ${employee.employeeId}
                        </span>

                    `;


                    result.addEventListener(
                        "click",
                        function() {

                            showEmployeeDetails(
                                employee
                            );

                        }
                    );


                    resultsContainer.appendChild(
                        result
                    );

                }
            );


            if (results.length === 0) {

                resultsContainer.innerHTML = `

                    <div class="employee-search-result">

                        No employee found.

                    </div>

                `;

            }

        }
    );



// ==================================================
// SHOW LIMITED EMPLOYEE INFORMATION
// ==================================================

function showEmployeeDetails(
    employee
) {

    const selectedEmployee =
        document.getElementById(
            "selectedEmployee"
        );


    const fullName =
        `${employee.firstName || ""} ${employee.lastName || ""}`
            .trim();


    selectedEmployee.innerHTML = `

        <h3>
            ${fullName || employee.employeeId}
        </h3>

        <p>
            <strong>Department:</strong>
            ${employee.department || "-"}
        </p>

        <p>
            <strong>Manager:</strong>
            ${employee.manager || "-"}
        </p>

        <p>
            <strong>Designation:</strong>
            ${employee.designation || "-"}
        </p>

    `;


    document.getElementById(
        "employeeSearchResults"
    ).innerHTML = "";

}



// ==================================================
// SEARCH DEPARTMENTS
// ==================================================

document
    .getElementById("departmentSearch")
    .addEventListener(
        "input",
        function() {

            const searchText =
                this.value
                    .toLowerCase()
                    .trim();


            const resultsContainer =
                document.getElementById(
                    "departmentSearchResults"
                );


            resultsContainer.innerHTML = "";


            if (searchText === "") {

                return;

            }


            const results =
                departments.filter(
                    department =>
                        department.departmentName
                            .toLowerCase()
                            .includes(searchText)
                );


            results.forEach(
                department => {

                    const result =
                        document.createElement(
                            "div"
                        );


                    result.className =
                        "department-search-result";


                    result.innerHTML = `

                        <strong>
                            ${department.departmentName}
                        </strong>

                        <span>
                            Manager:
                            ${department.manager}
                        </span>

                    `;


                    resultsContainer.appendChild(
                        result
                    );

                }
            );


            if (results.length === 0) {

                resultsContainer.innerHTML = `

                    <div class="department-search-result">

                        No department found.

                    </div>

                `;

            }

        }
    );



// ==================================================
// LOGOUT
// ==================================================

document
    .getElementById("employeeLogout")
    .addEventListener(
        "click",
        function(event) {

            event.preventDefault();


            const confirmLogout =
                confirm(
                    "Are you sure you want to logout?"
                );


            if (confirmLogout) {

                localStorage.removeItem(
                    "currentEmployeeId"
                );


                window.location.href =
                    "index.html";

            }

        }
    );



// ==================================================
// START
// ==================================================

loadEmployees();