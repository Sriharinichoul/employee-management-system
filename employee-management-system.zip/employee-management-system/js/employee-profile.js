// ===============================
// CURRENT EMPLOYEE
// ===============================

const currentEmployeeId =
    localStorage.getItem("currentEmployeeId");


// If there is no logged-in employee,
// go back to login

if (!currentEmployeeId) {

    window.location.href = "index.html";

}


// ===============================
// LOAD EMPLOYEE DATA
// ===============================

async function loadEmployee() {

    try {

        const response =
            await fetch("data/employees.json");


        if (!response.ok) {

            throw new Error(
                "Unable to load employee data."
            );

        }


        const employeesFromJSON =
            await response.json();


        const savedEmployees =
            JSON.parse(
                localStorage.getItem("employees")
            ) || [];


        // ===============================
        // MERGE EMPLOYEE DATA
        // ===============================

        const employeeMap =
            new Map();


        employeesFromJSON.forEach(employee => {

            employeeMap.set(
                employee.employeeId,
                employee
            );

        });


        savedEmployees.forEach(employee => {

            employeeMap.set(
                employee.employeeId,
                {
                    ...employeeMap.get(
                        employee.employeeId
                    ),
                    ...employee
                }
            );

        });


        const employees =
            Array.from(
                employeeMap.values()
            );


        // ===============================
        // FIND CURRENT EMPLOYEE
        // ===============================

        const employee =
            employees.find(
                employee =>
                    employee.employeeId ===
                    currentEmployeeId
            );


        if (!employee) {

            alert(
                "Employee information could not be found."
            );

            window.location.href =
                "index.html";

            return null;

        }


        return employee;


    } catch (error) {

        console.error(error);

        alert(
            "Unable to load employee information."
        );

        return null;

    }

}


// ===============================
// DISPLAY EMPLOYEE PROFILE
// ===============================

async function displayEmployeeProfile() {

    const employee =
        await loadEmployee();


    if (!employee) {

        return;

    }


    // ===============================
    // FULL NAME
    // ===============================

    const fullName =
        `${employee.firstName || ""} ${employee.lastName || ""}`
        .trim();


    const headerName =
        document.getElementById(
            "headerEmployeeName"
        );


    if (headerName) {

        headerName.textContent =
            fullName || "Employee";

    }


    // ===============================
    // ACCOUNT INFORMATION
    // ===============================

    document.getElementById(
        "employeeId"
    ).value =
        employee.employeeId || "";


    document.getElementById(
        "email"
    ).value =
        employee.email || "";


    // ===============================
    // PERSONAL INFORMATION
    // ===============================

    document.getElementById(
        "firstName"
    ).value =
        employee.firstName || "";


    document.getElementById(
        "lastName"
    ).value =
        employee.lastName || "";


    document.getElementById(
        "dateOfBirth"
    ).value =
        employee.dateOfBirth || "";


    document.getElementById(
        "phone"
    ).value =
        employee.phone || "";


    document.getElementById(
        "bloodGroup"
    ).value =
        employee.bloodGroup || "";


    // ===============================
    // ADDRESS
    // ===============================

    document.getElementById(
        "address"
    ).value =
        employee.address || "";


    document.getElementById(
        "city"
    ).value =
        employee.city || "";


    document.getElementById(
        "state"
    ).value =
        employee.state || "";


    document.getElementById(
        "postalCode"
    ).value =
        employee.postalCode || "";


    // ===============================
    // EMERGENCY CONTACT
    // ===============================

    document.getElementById(
        "emergencyContactName"
    ).value =
        employee.emergencyContactName || "";


    document.getElementById(
        "emergencyContactNumber"
    ).value =
        employee.emergencyContactNumber || "";


    document.getElementById(
        "emergencyContactRelationship"
    ).value =
        employee.emergencyContactRelationship || "";

}


displayEmployeeProfile();


// ===============================
// SAVE PROFILE
// ===============================

document
    .getElementById("employeeProfileForm")
    .addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();


            // ===============================
            // LOAD CURRENT EMPLOYEE
            // ===============================

            const employee =
                await loadEmployee();


            if (!employee) {

                return;

            }


            // ===============================
            // UPDATE PROFILE
            // ===============================

            employee.firstName =
                document.getElementById(
                    "firstName"
                ).value.trim();


            employee.lastName =
                document.getElementById(
                    "lastName"
                ).value.trim();


            employee.dateOfBirth =
                document.getElementById(
                    "dateOfBirth"
                ).value;


            employee.phone =
                document.getElementById(
                    "phone"
                ).value.trim();


            employee.bloodGroup =
                document.getElementById(
                    "bloodGroup"
                ).value;


            employee.address =
                document.getElementById(
                    "address"
                ).value.trim();


            employee.city =
                document.getElementById(
                    "city"
                ).value.trim();


            employee.state =
                document.getElementById(
                    "state"
                ).value.trim();


            employee.postalCode =
                document.getElementById(
                    "postalCode"
                ).value.trim();


            employee.emergencyContactName =
                document.getElementById(
                    "emergencyContactName"
                ).value.trim();


            employee.emergencyContactNumber =
                document.getElementById(
                    "emergencyContactNumber"
                ).value.trim();


            employee.emergencyContactRelationship =
                document.getElementById(
                    "emergencyContactRelationship"
                ).value.trim();


            // ===============================
            // GET SAVED EMPLOYEES
            // ===============================

            const savedEmployees =
                JSON.parse(
                    localStorage.getItem("employees")
                ) || [];


            // ===============================
            // UPDATE EMPLOYEE IN LOCAL STORAGE
            // ===============================

            const employeeIndex =
                savedEmployees.findIndex(
                    savedEmployee =>
                        savedEmployee.employeeId ===
                        currentEmployeeId
                );


            if (employeeIndex !== -1) {

                savedEmployees[employeeIndex] =
                    {
                        ...savedEmployees[employeeIndex],
                        ...employee
                    };

            } else {

                savedEmployees.push(employee);

            }


            // ===============================
            // FIRST LOGIN COMPLETE
            // ===============================

            employee.firstLogin = false;


            // Update the stored employee again
            // after changing firstLogin

            if (employeeIndex !== -1) {

                savedEmployees[employeeIndex] =
                    {
                        ...savedEmployees[employeeIndex],
                        ...employee
                    };

            }


            // ===============================
            // SAVE EMPLOYEE
            // ===============================

            localStorage.setItem(
                "employees",
                JSON.stringify(savedEmployees)
            );


            // ===============================
            // SUCCESS MESSAGE
            // ===============================

            alert(
                "Profile completed successfully!"
            );


            // ===============================
            // GO TO DASHBOARD
            // ===============================

            window.location.href =
                "employee-dashboard.html";

        }
    );


// ===============================
// CANCEL BUTTON
// ===============================

const cancelButton =
    document.getElementById("cancelButton");


if (cancelButton) {

    cancelButton.addEventListener(
        "click",
        function () {

            window.location.href =
                "employee-dashboard.html";

        }
    );

}


// ===============================
// LOGOUT
// ===============================

const logoutButton =
    document.getElementById("employeeLogout");


if (logoutButton) {

    logoutButton.addEventListener(
        "click",
        function (event) {

            event.preventDefault();


            const confirmLogout =
                confirm(
                    "Are you sure you want to logout?"
                );


            if (confirmLogout) {

                localStorage.removeItem(
                    "currentEmployeeId"
                );

                localStorage.removeItem(
                    "loggedInRole"
                );

                window.location.href =
                    "index.html";

            }

        }
    );

}