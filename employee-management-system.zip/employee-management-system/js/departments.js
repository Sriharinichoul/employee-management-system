let departments = [];

let selectedDepartment = null;



// ==================================================
// LOAD DEPARTMENTS
// ==================================================

fetch("data/departments.json")
    .then(response => response.json())
    .then(data => {

        const savedDepartments =
            JSON.parse(
                localStorage.getItem("departments")
            ) || [];


        // Start with departments from JSON

        departments = [...data];


        // Add or replace localStorage departments

        savedDepartments.forEach(
            savedDepartment => {

                const existingIndex =
                    departments.findIndex(
                        department =>
                            department.departmentId.toLowerCase() ===
                            savedDepartment.departmentId.toLowerCase()
                    );


                if (existingIndex !== -1) {

                    // Replace JSON department

                    departments[existingIndex] =
                        savedDepartment;

                } else {

                    // Add newly created department

                    departments.push(
                        savedDepartment
                    );

                }

            }
        );


        // Display departments

        displayDepartments(
            departments
        );

    })
    .catch(error => {

        console.error(
            "Error loading department data:",
            error
        );

    });



// ==================================================
// DISPLAY DEPARTMENTS
// ==================================================

function displayDepartments(
    departmentList
) {

    const tableBody =
        document.getElementById(
            "departmentTableBody"
        );


    tableBody.innerHTML = "";


    departmentList.forEach(
        department => {

            const row =
                document.createElement("tr");


            row.innerHTML = `

                <td>
                    ${department.departmentId}
                </td>

                <td>
                    ${department.departmentName}
                </td>

                <td>
                    ${department.manager}
                </td>

                <td>
                    ${department.status}
                </td>

                <td>

                    <button
                        class="edit-button"
                        onclick="openDepartmentEdit('${department.departmentId}')"
                    >
                        Edit
                    </button>

                </td>

            `;


            tableBody.appendChild(row);

        }
    );

}



// ==================================================
// SEARCH DEPARTMENTS
// ==================================================

const searchDepartment =
    document.getElementById(
        "searchDepartment"
    );


searchDepartment.addEventListener(
    "input",
    function() {

        const searchText =
            this.value
                .toLowerCase()
                .trim();


        const filteredDepartments =
            departments.filter(
                department =>
                    department.departmentName
                        .toLowerCase()
                        .includes(searchText)
            );


        displayDepartments(
            filteredDepartments
        );

    }
);



// ==================================================
// OPEN EDIT FORM
// ==================================================

function openDepartmentEdit(
    departmentId
) {

    selectedDepartment =
        departments.find(
            department =>
                department.departmentId.toLowerCase() ===
                departmentId.toLowerCase()
        );


    if (!selectedDepartment) {

        alert(
            "Department not found."
        );

        return;
    }


    // Fill form

    document.getElementById(
        "departmentId"
    ).value =
        selectedDepartment.departmentId;


    document.getElementById(
        "departmentName"
    ).value =
        selectedDepartment.departmentName;


    document.getElementById(
        "manager"
    ).value =
        selectedDepartment.manager;


    document.getElementById(
        "status"
    ).value =
        selectedDepartment.status;


    // Show form

    document
        .getElementById(
            "editDepartmentContainer"
        )
        .classList.add(
            "show"
        );


    // Scroll to form

    document
        .getElementById(
            "editDepartmentContainer"
        )
        .scrollIntoView({
            behavior: "smooth"
        });

}



// ==================================================
// UPDATE DEPARTMENT
// ==================================================

document
    .getElementById("departmentForm")
    .addEventListener(
        "submit",
        function(event) {

            event.preventDefault();


            if (!selectedDepartment) {

                alert(
                    "Please select a department first."
                );

                return;
            }


            const updatedDepartment = {

                departmentId:
                    document.getElementById(
                        "departmentId"
                    ).value,

                departmentName:
                    document.getElementById(
                        "departmentName"
                    ).value,

                manager:
                    document.getElementById(
                        "manager"
                    ).value.trim(),

                status:
                    document.getElementById(
                        "status"
                    ).value

            };


            // Get saved departments

            const savedDepartments =
                JSON.parse(
                    localStorage.getItem(
                        "departments"
                    )
                ) || [];


            // Find existing department

            const existingIndex =
                savedDepartments.findIndex(
                    department =>
                        department.departmentId.toLowerCase() ===
                        updatedDepartment.departmentId.toLowerCase()
                );


            if (existingIndex !== -1) {

                // Update existing localStorage department

                savedDepartments[
                    existingIndex
                ] =
                    updatedDepartment;

            } else {

                // Save JSON department's updated version

                savedDepartments.push(
                    updatedDepartment
                );

            }


            // Save to localStorage

            localStorage.setItem(
                "departments",
                JSON.stringify(
                    savedDepartments
                )
            );


            // Update current list

            departments =
                departments.map(
                    department => {

                        if (
                            department.departmentId.toLowerCase() ===
                            updatedDepartment.departmentId.toLowerCase()
                        ) {

                            return updatedDepartment;

                        }

                        return department;

                    }
                );


            // Refresh table

            displayDepartments(
                departments
            );


            alert(
                "Department updated successfully!"
            );


            // Hide form

            document
                .getElementById(
                    "editDepartmentContainer"
                )
                .classList.remove(
                    "show"
                );


            selectedDepartment =
                null;

        }
    );



// ==================================================
// CANCEL EDIT
// ==================================================

document
    .getElementById(
        "cancelDepartmentEdit"
    )
    .addEventListener(
        "click",
        function() {

            document
                .getElementById(
                    "editDepartmentContainer"
                )
                .classList.remove(
                    "show"
                );


            selectedDepartment =
                null;

        }
    );