let employees = [];

let departments = [];

let selectedEmployee = null;



// ==================================================
// LOAD EMPLOYEES
// ==================================================

function loadEmployees() {

    fetch("data/employees.json")
        .then(response => {

            if (!response.ok) {

                throw new Error(
                    "Could not load employees.json"
                );

            }

            return response.json();

        })
        .then(data => {

            // Get employees added or updated
            // through the application

            const savedEmployees =
                JSON.parse(
                    localStorage.getItem("employees")
                ) || [];


            // Start with JSON employees

            employees = [...data];


            // Add or replace localStorage employees

            savedEmployees.forEach(
                savedEmployee => {

                    const existingIndex =
                        employees.findIndex(
                            employee =>
                                employee.employeeId
                                    .toLowerCase() ===
                                savedEmployee.employeeId
                                    .toLowerCase()
                        );


                    if (existingIndex !== -1) {

                        // Replace JSON employee
                        // with updated employee

                        employees[existingIndex] =
                            {
                                ...employees[
                                    existingIndex
                                ],
                                ...savedEmployee
                            };

                    } else {

                        // Add newly created employee

                        employees.push(
                            savedEmployee
                        );

                    }

                }
            );


            // Display employee list

            displayEmployees(
                employees
            );


            // Load departments

            loadDepartments();

        })
        .catch(error => {

            console.error(
                "Error loading employees:",
                error
            );

        });

}



// ==================================================
// DISPLAY EMPLOYEES
// ==================================================

function displayEmployees(
    employeeList
) {

    const tableBody =
        document.getElementById(
            "employeeTableBody"
        );


    tableBody.innerHTML = "";


    if (employeeList.length === 0) {

        tableBody.innerHTML = `

            <tr>

                <td
                    colspan="7"
                    style="text-align: center;"
                >
                    No employees found.
                </td>

            </tr>

        `;

        return;

    }


    employeeList.forEach(
        employee => {

            const row =
                document.createElement("tr");


            row.innerHTML = `

                <td>
                    ${employee.employeeId}
                </td>

                <td>
                    ${employee.email || "-"}
                </td>

                <td>
                    ${employee.department || "-"}
                </td>

                <td>
                    ${employee.designation || "-"}
                </td>

                <td>
                    ${employee.joiningDate || "-"}
                </td>

                <td>
                    ${employee.status || "-"}
                </td>

                <td>

                    <button
                        class="edit-button"
                        onclick="openEditForm('${employee.employeeId}')"
                    >
                        Edit
                    </button>

                </td>

            `;


            tableBody.appendChild(
                row
            );

        }
    );

}



// ==================================================
// LOAD DEPARTMENTS
// ==================================================

function loadDepartments() {

    fetch("data/departments.json")
        .then(response => {

            if (!response.ok) {

                throw new Error(
                    "Could not load departments.json"
                );

            }

            return response.json();

        })
        .then(data => {

            const savedDepartments =
                JSON.parse(
                    localStorage.getItem("departments")
                ) || [];


            departments = [...data];


            savedDepartments.forEach(
                savedDepartment => {

                    const existingIndex =
                        departments.findIndex(
                            department =>
                                department.departmentId
                                    .toLowerCase() ===
                                savedDepartment.departmentId
                                    .toLowerCase()
                        );


                    if (existingIndex !== -1) {

                        departments[existingIndex] =
                            savedDepartment;

                    } else {

                        departments.push(
                            savedDepartment
                        );

                    }

                }
            );


            populateDepartmentDropdown();

        })
        .catch(error => {

            console.error(
                "Error loading departments:",
                error
            );

        });

}



// ==================================================
// DEPARTMENT DROPDOWN
// ==================================================

function populateDepartmentDropdown() {

    const departmentSelect =
        document.getElementById(
            "department"
        );


    departmentSelect.innerHTML = `
        <option value="">
            Select Department
        </option>
    `;


    departments.forEach(
        department => {

            const option =
                document.createElement(
                    "option"
                );


            option.value =
                department.departmentName;


            option.textContent =
                department.departmentName;


            departmentSelect.appendChild(
                option
            );

        }
    );

}



// ==================================================
// DEPARTMENT CHANGE
// ==================================================

document
    .getElementById("department")
    .addEventListener(
        "change",
        function() {

            populateManagerDropdown(
                this.value
            );

        }
    );



// ==================================================
// MANAGER DROPDOWN
// ==================================================

function populateManagerDropdown(
    departmentName,
    selectedManager = ""
) {

    const managerSelect =
        document.getElementById(
            "manager"
        );


    managerSelect.innerHTML = `
        <option value="">
            Select Manager
        </option>
    `;


    const department =
        departments.find(
            department =>
                department.departmentName ===
                departmentName
        );


    if (!department) {

        return;

    }


    const option =
        document.createElement(
            "option"
        );


    option.value =
        department.manager;


    option.textContent =
        department.manager;


    managerSelect.appendChild(
        option
    );


    if (
        selectedManager !== ""
    ) {

        managerSelect.value =
            selectedManager;

    }

}



// ==================================================
// OPEN EDIT FORM
// ==================================================

function openEditForm(
    employeeId
) {

    selectedEmployee =
        employees.find(
            employee =>
                employee.employeeId
                    .toLowerCase() ===
                employeeId
                    .toLowerCase()
        );


    if (!selectedEmployee) {

        alert(
            "Employee not found."
        );

        return;

    }


    document.getElementById(
        "employeeId"
    ).value =
        selectedEmployee.employeeId;


    document.getElementById(
        "email"
    ).value =
        selectedEmployee.email || "";


    document.getElementById(
        "designation"
    ).value =
        selectedEmployee.designation || "";


    document.getElementById(
        "joiningDate"
    ).value =
        selectedEmployee.joiningDate || "";


    document.getElementById(
        "status"
    ).value =
        selectedEmployee.status || "Active";


    // Department

    document.getElementById(
        "department"
    ).value =
        selectedEmployee.department || "";


    // Manager

    populateManagerDropdown(
        selectedEmployee.department || "",
        selectedEmployee.manager || ""
    );


    // Show edit form

    document
        .getElementById(
            "editFormContainer"
        )
        .classList.add(
            "show"
        );


    // Scroll to form

    document
        .getElementById(
            "editFormContainer"
        )
        .scrollIntoView({
            behavior: "smooth"
        });

}



// ==================================================
// SEARCH EMPLOYEES
// ==================================================

document
    .getElementById("employeeSearch")
    .addEventListener(
        "input",
        function() {

            const searchText =
                this.value
                    .toLowerCase()
                    .trim();


            const filteredEmployees =
                employees.filter(
                    employee => {

                        const employeeId =
                            (
                                employee.employeeId ||
                                ""
                            ).toLowerCase();


                        const email =
                            (
                                employee.email ||
                                ""
                            ).toLowerCase();


                        return (
                            employeeId.includes(
                                searchText
                            ) ||
                            email.includes(
                                searchText
                            )
                        );

                    }
                );


            displayEmployees(
                filteredEmployees
            );

        }
    );



// ==================================================
// UPDATE EMPLOYEE
// ==================================================

document
    .getElementById("employeeForm")
    .addEventListener(
        "submit",
        function(event) {

            event.preventDefault();


            if (!selectedEmployee) {

                alert(
                    "Please select an employee first."
                );

                return;

            }


            const updatedEmployee = {

                employeeId:
                    document.getElementById(
                        "employeeId"
                    ).value,

                firstName:
                    selectedEmployee.firstName || "",

                lastName:
                    selectedEmployee.lastName || "",

                email:
                    document.getElementById(
                        "email"
                    ).value,

                mobileNumber:
                    selectedEmployee.mobileNumber || "",

                dateOfBirth:
                    selectedEmployee.dateOfBirth || "",

                bloodGroup:
                    selectedEmployee.bloodGroup || "",

                address:
                    selectedEmployee.address || "",

                city:
                    selectedEmployee.city || "",

                state:
                    selectedEmployee.state || "",

                postalCode:
                    selectedEmployee.postalCode || "",

                emergencyContactName:
                    selectedEmployee.emergencyContactName || "",

                emergencyContactNumber:
                    selectedEmployee.emergencyContactNumber || "",

                emergencyContactRelationship:
                    selectedEmployee.emergencyContactRelationship || "",

                department:
                    document.getElementById(
                        "department"
                    ).value,

                manager:
                    document.getElementById(
                        "manager"
                    ).value,

                designation:
                    document.getElementById(
                        "designation"
                    ).value.trim(),

                joiningDate:
                    document.getElementById(
                        "joiningDate"
                    ).value,

                status:
                    document.getElementById(
                        "status"
                    ).value,

                firstLogin:
                    selectedEmployee.firstLogin || false

            };


            // Get saved employees

            const savedEmployees =
                JSON.parse(
                    localStorage.getItem(
                        "employees"
                    )
                ) || [];


            // Find employee

            const existingIndex =
                savedEmployees.findIndex(
                    employee =>
                        employee.employeeId
                            .toLowerCase() ===
                        updatedEmployee.employeeId
                            .toLowerCase()
                );


            if (existingIndex !== -1) {

                savedEmployees[
                    existingIndex
                ] =
                    updatedEmployee;

            } else {

                savedEmployees.push(
                    updatedEmployee
                );

            }


            // Save

            localStorage.setItem(
                "employees",
                JSON.stringify(
                    savedEmployees
                )
            );


            // Update current array

            employees =
                employees.map(
                    employee => {

                        if (
                            employee.employeeId
                                .toLowerCase() ===
                            updatedEmployee.employeeId
                                .toLowerCase()
                        ) {

                            return updatedEmployee;

                        }

                        return employee;

                    }
                );


            // Refresh table

            displayEmployees(
                employees
            );


            alert(
                "Employee updated successfully!"
            );


            // Hide form

            document
                .getElementById(
                    "editFormContainer"
                )
                .classList.remove(
                    "show"
                );


            selectedEmployee =
                null;

        }
    );



// ==================================================
// CANCEL
// ==================================================

document
    .getElementById("cancelEdit")
    .addEventListener(
        "click",
        function() {

            document
                .getElementById(
                    "editFormContainer"
                )
                .classList.remove(
                    "show"
                );


            selectedEmployee =
                null;

        }
    );



// ==================================================
// START APPLICATION
// ==================================================

loadEmployees();